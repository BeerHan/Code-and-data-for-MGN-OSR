#!/bin/bash

for file in ./*.pcap
do
  if [ -d "$file" ]
  then
    echo "$file is directory"
  elif [ -f "$file" ]
  then
    echo "$file is file"
    mkdir -p ./session_pcap
    PcapSplitter -f $file -o "./session_pcap/" -m connection
  fi
done
find ./session_pcap/* -size -8 | xargs du | cut -f2 | xargs rm
mergecap -w output.pcap ./session_pcap/*
