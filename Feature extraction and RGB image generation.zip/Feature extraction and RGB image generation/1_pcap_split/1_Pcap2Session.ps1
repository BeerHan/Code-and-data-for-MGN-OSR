# SplitCap: https://www.netresec.com/index.ashx?page=SplitCap
# -p <nr_parallel_sessions> : Set the number of parallel sessions to keep in memory (default = 10000). More sessions might be needed to split pcap files from busy links such as an Internet backbone link, this will however require more memory
# -b <file_buffer_bytes> : Set the number of bytes to buffer for each session/output file (default = 10000). Larger buffers will speed up the process due to fewer disk write operations, but will occupy more memory.
# -s <GROUP> : Split traffic and group packets to pcap files based on <GROUP>. Possible values for <GROUP> are:
#   bssid : Traffic grouped based on WLAN BSSID
#   flow : Each flow, i.e. unidirectional traffic for a 5-tuple, is grouped
#   host : Traffic grouped to one file per host. Most packets will end up in two files.
#   hostpair : Traffic grouped based on host-pairs communicating
#   mac : Traffic grouped to one file per MAC address. Most packets will end up in two files.
#   nosplit : Do not split traffic. Only create ONE output pcap.
#   (default) session : Packets for each session (bi-directional flow) are grouped
#   seconds <s> : Split on time, new file after <s> seconds.
#   packets <c> : Split on packet count, new file after <c> packets.
# -y <FILETYPE> : Output file type for extracted data. Possible values for <FILETYPE> are:
#   L7 : Only store application layer data
#   (default) pcap : Store complete pcap frames

foreach($f in Get-ChildItem *.pcap)
{
    0_Tool\SplitCap_2-1\SplitCap -p 50000 -b 50000 -r $f.FullName -o 2_Session\SessionAllLayers\$($f.BaseName)-ALL
    Get-ChildItem 2_Session\SessionAllLayers\$($f.BaseName)-ALL | ?{$_.Length -eq 0} | del
    0_Tool\SplitCap_2-1\SplitCap -p 50000 -b 50000 -r $f.FullName -s flow -o 2_Session\FlowAllLayers\$($f.BaseName)-ALL
    Get-ChildItem 2_Session\FlowAllLayers\$($f.BaseName)-ALL | ?{$_.Length -eq 0} | del

    0_Tool\SplitCap_2-1\SplitCap -p 50000 -b 50000 -r $f.FullName -o 2_Session\SessionL7\$($f.BaseName)-L7 -y L7
    Get-ChildItem 2_Session\SessionL7\$($f.BaseName)-L7 | ?{$_.Length -eq 0} | del
    0_Tool\SplitCap_2-1\SplitCap -p 50000 -b 50000 -r $f.FullName -s flow -o 2_Session\FlowL7\$($f.BaseName)-L7 -y L7
    Get-ChildItem 2_Session\FlowL7\$($f.BaseName)-L7 | ?{$_.Length -eq 0} | del
}

0_Tool\finddupe -del 2_Session\SessionAllLayers
0_Tool\finddupe -del 2_Session\FlowAllLayers
0_Tool\finddupe -del 2_Session\SessionL7
0_Tool\finddupe -del 2_Session\FlowL7