$SESSIONS_COUNT_LIMIT_MIN = 0
$SESSIONS_COUNT_LIMIT_MAX = 60000
$TRIMED_FILE_LEN = 784

Write-Output "If Sessions more than $SESSIONS_COUNT_LIMIT_MAX we only select the largest $SESSIONS_COUNT_LIMIT_MAX."
Write-Output "Finally Selected Sessions:"

$SOURCE_SESSION_DIR = @(("2_Session\SessionAllLayers"), ("2_Session\FlowAllLayers"), ("2_Session\SessionL7"), ("2_Session\FlowL7"))
foreach($root_dirs in $SOURCE_SESSION_DIR){
    $dirs = Get-ChildItem $root_dirs -Directory
    foreach($d in $dirs)
    {
        $files = Get-ChildItem $d.FullName
        $count = $files.count
        if($count -gt $SESSIONS_COUNT_LIMIT_MIN)
        {             
            Write-Output "$($d.Name) $count"        
            if($count -gt $SESSIONS_COUNT_LIMIT_MAX)
            {
                $files = $files | Sort-Object Length -Descending | Select-Object -First $SESSIONS_COUNT_LIMIT_MAX
                $count = $SESSIONS_COUNT_LIMIT_MAX
            }
    
            $files = $files | resolve-path
            $test  = $files | get-random -count ([int]($count/10))
            $train = $files | ?{$_ -notin $test}     
    
            $path_test  = "3_ProcessedSession\FilteredSession\Test\$($d.Name)"
            $path_train = "3_ProcessedSession\FilteredSession\Train\$($d.Name)"
            New-Item -Path $path_test -ItemType Directory -Force
            New-Item -Path $path_train -ItemType Directory -Force    
    
            Copy-Item $test -destination $path_test        
            Copy-Item $train -destination $path_train
        }
    }
}

Write-Output "All files will be trimed to $TRIMED_FILE_LEN length and if it's even shorter we'll fill the end with 0x00..."

$paths = @(('3_ProcessedSession\FilteredSession\Train', '3_ProcessedSession\TrimedSession\Train'), ('3_ProcessedSession\FilteredSession\Test', '3_ProcessedSession\TrimedSession\Test'))
foreach($p in $paths)
{
    foreach ($d in Get-ChildItem $p[0] -Directory) 
    {
        New-Item -Path "$($p[1])\$($d.Name)" -ItemType Directory -Force
        foreach($f in Get-ChildItem $d.fullname)
        {
            $content = [System.IO.File]::ReadAllBytes($f.FullName)
            $len = $f.length - $TRIMED_FILE_LEN
            if($len -gt 0)
            {        
                $content = $content[0..($TRIMED_FILE_LEN-1)]        
            }
            elseif($len -lt 0)
            {        
                $padding = [Byte[]] (,0x00 * ([math]::abs($len)))
                $content = $content += $padding
            }
            Set-Content -value $content -encoding byte -path "$($p[1])\$($d.Name)\$($f.Name)"
        }        
    }
}