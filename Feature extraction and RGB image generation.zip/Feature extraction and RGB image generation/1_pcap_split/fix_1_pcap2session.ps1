# SplitCap: https://www.netresec.com/index.ashx?page=SplitCap
# -p <nr_parallel_sessions> : Set the number of parallel sessions to keep in memory (default = 10000). More sessions might be needed to split pcap files from busy links such as an Internet backbone link, this will however require more memory
# -b <file_buffer_bytes> : Set the number of bytes to buffer for each session/output file (default = 10000). Larger buffers will speed up the process due to fewer disk write operations, but will occupy more memory.

foreach($f in Get-ChildItem *.pcap)
{
    0_Tool\SplitCap_2-1\SplitCap -p 50000 -b 50000 -r $f.FullName -o 2_Session\$($f.BaseName)
    Get-ChildItem 2_Session\$($f.BaseName) | ?{$_.Length -eq 0} | del
}

0_Tool\finddupe -del 2_Session