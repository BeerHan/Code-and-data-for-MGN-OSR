import os
import binascii
import numpy
# pip install pillow -> PIL
from PIL import Image

PNG_SIZE = 28


def getMatrix_from_pcap(filename, width):
    with open(filename, "rb") as f:
        content = f.read()
    hexst = binascii.hexlify(content)
    fh = numpy.array([int(hexst[i:i + 2], 16) for i in range(0, len(hexst), 2)])
    rn = len(fh) // width
    fh = numpy.reshape(fh[:rn * width], (-1, width))
    fh = numpy.uint8(fh)
    return fh


def mkdir(path):
    path = path.strip()
    path = path.rstrip("\\")
    isExists = os.path.exists(path)
    if not isExists:
        os.makedirs(path)
        print(path + " Created successfully")
        return True
    else:
        print(path + " Already exists")
        return False


def session2png(src_dst_paths):
    for src_dst_path in src_dst_paths:
        for src_idx, src_filename in enumerate(os.listdir(src_dst_path[0])):
            dst_path = os.path.join(src_dst_path[1], str(src_idx))
            mkdir(dst_path)
            for dst_filename in os.listdir(os.path.join(src_dst_path[0], src_filename)):
                bin_full_path = os.path.join(src_dst_path[0], src_filename, dst_filename)
                im = Image.fromarray(getMatrix_from_pcap(bin_full_path, PNG_SIZE))
                png_full_path = os.path.join(dst_path, os.path.splitext(dst_filename)[0] + ".png")
                im.save(png_full_path)


if __name__ == "__main__":
    src_dst_paths = [["3_processedsession/trimedsession/train", "4_png/train"],
                     ["3_ProcessedSession/TrimedSession/Test", "4_Png/Test"], ]
    session2png(src_dst_paths)
