import os
from PIL import Image
from array import array
from random import shuffle


def mkdir(path):
    path = path.strip()
    path = path.rstrip("\\")
    isExists = os.path.exists(path)
    if not isExists:
        os.makedirs(path)
        print(path + " Created successfully")
        return True
    else:
        print(path + " Already exists")
        return False


def png2mnist(src_dst_paths):
    # Load from and save to
    for src_dst_path in src_dst_paths:
        data_image = array("B")
        data_label = array("B")
        png_list = []
        for src_path in os.listdir(src_dst_path[0]):
            for png_name in os.listdir(os.path.join(src_dst_path[0], src_path)):
                if png_name.endswith(".png"):
                    png_list.append(os.path.join(src_dst_path[0], src_path, png_name))

        # Usefull for further segmenting the validation set
        shuffle(png_list)

        for png_name in png_list:
            print(png_name)
            label = int(png_name.split("/")[2])
            Im = Image.open(png_name)
            pixel = Im.load()
            width, height = Im.size
            for x in range(0, width):
                for y in range(0, height):
                    data_image.append(pixel[y, x])
            # labels start (one unsigned byte each)
            data_label.append(label)

        # number of files in HEX
        hexval = "{0:#0{1}x}".format(len(png_list), 6)
        hexval = "0x" + hexval[2:].zfill(8)

        # header for label array
        header = array("B")
        header.extend([0, 0, 8, 1])
        header.append(int("0x" + hexval[2:][0:2], 16))
        header.append(int("0x" + hexval[2:][2:4], 16))
        header.append(int("0x" + hexval[2:][4:6], 16))
        header.append(int("0x" + hexval[2:][6:8], 16))
        data_label = header + data_label

        # additional header for images array
        if max([width, height]) <= 256:
            header.extend([0, 0, 0, width, 0, 0, 0, height])
        else:
            raise ValueError("Image exceeds maximum size: 256x256 pixels")

        header[3] = 3  # Changing MSB for image data (0x00000803)
        data_image = header + data_image
        output_file = open(src_dst_path[1] + "-images-idx3-ubyte", "wb")
        data_image.tofile(output_file)
        output_file.close()
        output_file = open(src_dst_path[1] + "-labels-idx1-ubyte", "wb")
        data_label.tofile(output_file)
        output_file.close()


def gzip_idx(src_dst_paths):
    # gzip resulting files
    for src_dst_path in src_dst_paths:
        os.system("gzip " + src_dst_path[1] + "-images-idx3-ubyte")
        os.system("gzip " + src_dst_path[1] + "-labels-idx1-ubyte")


if __name__ == '__main__':
    mkdir("5_Mnist")
    src_dst_path = [["4_Png/Train", "5_Mnist/train"], ["4_Png/Test", "5_Mnist/test"], ]
    png2mnist(src_dst_path)
    gzip_idx(src_dst_path)
