import os
import binascii
import numpy
# pip install pillow -> PIL
from PIL import Image

from scapy.all import *
from datetime import datetime
import json

PNG_WIDTH = 64
PNG_HEIGHT = 128
PNG_ALL = PNG_WIDTH * PNG_HEIGHT


class TLSPcapDecode:
    data = dict()

    def __init__(self):
        # ETHER:读取以太网层协议配置文件
        with open('./protocol/ETHER', 'r', encoding='UTF-8') as f:
            ethers = f.readlines()
        self.ETHER_DICT = dict()
        for ether in ethers:
            ether = ether.strip().strip('\n').strip('\r').strip('\r\n')
            self.ETHER_DICT[int(ether.split(':')[0])] = ether.split(':')[1]

        # IP:读取IP层协议配置文件
        with open('./protocol/IP', 'r', encoding='UTF-8') as f:
            ips = f.readlines()
        self.IP_DICT = dict()
        for ip in ips:
            ip = ip.strip().strip('\n').strip('\r').strip('\r\n')
            self.IP_DICT[int(ip.split(':')[0])] = ip.split(':')[1]

        # PORT:读取应用层协议端口配置文件
        with open('./protocol/PORT', 'r', encoding='UTF-8') as f:
            ports = f.readlines()
        self.PORT_DICT = dict()
        for port in ports:
            port = port.strip().strip('\n').strip('\r').strip('\r\n')
            self.PORT_DICT[int(port.split(':')[0])] = port.split(':')[1]

        # TCP:读取TCP层协议配置文件
        with open('./protocol/TCP', 'r', encoding='UTF-8') as f:
            tcps = f.readlines()
        self.TCP_DICT = dict()
        for tcp in tcps:
            tcp = tcp.strip().strip('\n').strip('\r').strip('\r\n')
            self.TCP_DICT[int(tcp.split(':')[0])] = tcp.split(':')[1]

    # 解析以太网层协议
    def ether_decode(self, p):
        ether_data = dict()
        if p.haslayer("Ether"):
            # p.time -> 毫秒时间戳
            ether_data['time'] = datetime.fromtimestamp(float(p.time)).strftime('%Y-%m-%d %H:%M:%S.%f')
            ether_data['len'] = len(corrupt_bytes(p))
            # ether_data['info'] = p.summary()
            if p.haslayer("IP"):
                ether_data['IP'] = self.ip_decode(p)
            # 赋给类公有变量
            self.data.update(ether_data)
            return self.data
        else:
            ether_data['ether_error'] = False
            self.data.update(ether_data)
            return self.data

    # 解析IP层协议
    def ip_decode(self, p):
        ip_data = dict()
        if p.haslayer("IP"):
            ip = p.getlayer("IP")
            ip_data['source'] = ip.src + ":" + str(ip.sport)
            ip_data['destination'] = ip.dst + ":" + str(ip.dport)
            if p.haslayer("TCP"):
                ip_data['TCP'] = self.tcp_decode(p, ip)
                return ip_data
        elif p.haslayer("IPv6"):
            ipv6 = p.getlayer("IPv6")
            # 未处理
            if p.haslayer("TCP"):
                ip_data = self.tcp_decode(p, ipv6)
                return ip_data
        else:
            ip_data['ip_error'] = False
            return ip_data

    # 解析TCP层协议
    def tcp_decode(self, p, ip):
        tcp_data = dict()
        if p.haslayer("TCP"):
            tcp = p.getlayer("TCP")
            if tcp.dport in self.PORT_DICT:
                tcp_data['Procotol'] = self.PORT_DICT[tcp.dport]
            elif tcp.sport in self.PORT_DICT:
                tcp_data['Procotol'] = self.PORT_DICT[tcp.sport]
            elif tcp.dport in self.TCP_DICT:
                tcp_data['Procotol'] = self.TCP_DICT[tcp.dport]
            elif tcp.sport in self.TCP_DICT:
                tcp_data['Procotol'] = self.TCP_DICT[tcp.sport]
            else:
                tcp_data['Procotol'] = "TCP"
            # tcp.show()
            # 此处非TLS，而是SSL/TLS
            if p.haslayer("SSL/TLS"):
                tcp_data['TLS'] = self.tls_decode(p, ip, tcp)
                return tcp_data
            else:
                return tcp_data
        else:
            tcp_data['tcp_error'] = False
            return tcp_data

    # 解析TLS协议
    def tls_decode(self, p, ip, tcp):
        tls_data = dict()
        if p.haslayer("SSL/TLS"):
            tls = p.getlayer("SSL/TLS")
            time.sleep(1)
            # ls(tls)
            # tls.show()
            try:
                # print(str(tls['TLS Record']) + str(tls['TLS Handshake']))
                tls_data['tls_ca_data'] = str(tls['TLS Record']) + str(tls['TLS Handshake'])
            except:
                # print(str(tls['TLS Record']))
                tls_data['tls_ca_data'] = ""
            try:
                # tls version TLS 1.2 0x0303 -> 771
                tls_data['tls_vers'] = tls['TLS Record'].version
            except IndexError:
                tls_data['tls_vers'] = 0
            try:
                # get tls length
                tls_data['tls_len'] = tls['TLS Record'].length
            except:
                tls_data['tls_len'] = 0
            # get tls duration
            # get ssl/tls stage 2 info
            try:
                tls['TLS Handshake']
            except IndexError:
                tls_data['tls_step'] = -1
            else:
                tls_data['tls_step'] = tls['TLS Handshake'].type
                # stage 2: Server Hello
                if tls_data['tls_step'] == 2:
                    # tls cipher ECDHE_RSA_WITH_AES_128_CBC_SHA256 0xc027 -> 49191
                    tls_data['tls_cip'] = tls['TLS Handshake'].cipher_suite
                    # tls compression method 0x00 -> 0
                    tls_data['tls_comp'] = tls['TLS Handshake'].compression_method
                    # tls extensions length 0x8 -> 8
                    tls_data['tls_extlen'] = tls['TLS Handshake'].extensions_length
                    # tls extensions type 0x000b -> 11
                    tls_data['tls_exttype'] = tls['TLS Extension'].type
            return tls_data
        else:
            tls_data['tls_error'] = False
            return tls_data


# SSL/TLS特征
# Note: for 异常处理
def get_ssl_tls_feature(session_pcap, TLSPD):
    pkt_num = 0
    tls_num = 0
    si_sport_di_dport = ""  # sip sport dip dport
    pkt_len = []  # packet length
    tls_len = []  # tls length
    tls_cip, tls_comp, tls_extlen, tls_exttype = 0, 0, 0, 0
    tls_ca_data = []
    # get tls duration
    for p in session_pcap:
        pkt_num += 1  # Session中packet NO.
        # print("\n", "-" * 15, "Packet: %d" % pkt_num, "-" * 15)
        # packet decode
        data_result_dict = TLSPcapDecode.ether_decode(TLSPD, p)
        data_result = json.dumps(data_result_dict, indent=2)  # dict -> str; indent 缩进
        # print(data_result)
        si_sport_di_dport = data_result_dict['IP']['source'] + "-" + data_result_dict['IP']['destination']
        pkt_len.append(data_result_dict['len'])
        # return tls info
        try:
            data_result_dict['IP']['TCP']['TLS']
        except KeyError:
            tls_len.append(0)
        else:
            tls_num += 1
            tls_len.append(data_result_dict['IP']['TCP']['TLS']['tls_len'])
            tls_ca_data.append(data_result_dict['IP']['TCP']['TLS']['tls_ca_data'])
            if data_result_dict['IP']['TCP']['TLS']['tls_step'] == 2:
                tls_cip = data_result_dict['IP']['TCP']['TLS']['tls_cip']
                tls_comp = data_result_dict['IP']['TCP']['TLS']['tls_comp']
                tls_extlen = data_result_dict['IP']['TCP']['TLS']['tls_extlen']
                tls_exttype = data_result_dict['IP']['TCP']['TLS']['tls_exttype']

    return si_sport_di_dport, pkt_len, tls_num, tls_len, tls_cip, tls_comp, tls_extlen, tls_exttype, tls_ca_data


# 会话流统计特征
def get_session_statistic_feature(session_pcap, TLSPD):
    session_statistic_features = dict()
    si_sport_di_dport, pkt_len, tlss_cnt, tls_len, tls_cip, tls_comp, tls_extlen, tls_exttype, tls_ca_data = get_ssl_tls_feature(
        session_pcap, TLSPD)
    session_statistic_features['si_sport_di_dport'] = si_sport_di_dport
    pkts_cnt = len(session_pcap)  # 数据包数量
    session_statistic_features['pkts_cnt'] = pkts_cnt
    if pkts_cnt:
        sessn_dur = session_pcap[pkts_cnt - 1].time - session_pcap[0].time  # Session持续时间
        session_statistic_features['sessn_dur'] = float(sessn_dur)
    total_bytes = sum(pkt_len)  # Session总字节数
    session_statistic_features['total_bytes'] = total_bytes
    pkts_len_avg = total_bytes / (pkts_cnt - 3)  # pactet包长平均值，排除tcp三次握手
    session_statistic_features['pkts_len_avg'] = pkts_len_avg
    total_bytes_tls = sum(tls_len)  # tls总字节数
    session_statistic_features['total_bytes_tls'] = total_bytes_tls
    try:
        tlss_len_avg = total_bytes_tls / tlss_cnt
    except ZeroDivisionError:
        tlss_len_avg = 0
    session_statistic_features['tlss_len_avg'] = tlss_len_avg
    session_statistic_features['tls_cip'] = tls_cip
    session_statistic_features['tls_comp'] = tls_comp
    session_statistic_features['tls_extlen'] = tls_extlen
    session_statistic_features['tls_exttype'] = tls_exttype
    tls_ca_data = "".join(tls_ca_data)  # 证书等明文信息
    session_statistic_features['tls_ca_data'] = tls_ca_data
    print(session_statistic_features)
    return session_statistic_features


def getMatrix_from_pcap(filename, width):
    with open(filename, "rb") as f:
        content = f.read()
    if len(content) <= PNG_ALL:
        content = content.ljust(PNG_ALL)
    else:
        content = content[:PNG_ALL]
    hexst = binascii.hexlify(content)
    fh = numpy.array([int(hexst[i:i + 2], 16) for i in range(0, len(hexst), 2)])
    rn = len(fh) // width
    fh = numpy.reshape(fh[:rn * width], (-1, width))
    fh = numpy.uint8(fh)
    return fh


def getMatrix_from_str(content, width):
    if len(content) <= PNG_ALL:
        content = content.encode().ljust(PNG_ALL)
    else:
        content = content.encode()[:PNG_ALL]
    hexst = binascii.hexlify(content)
    fh = numpy.array([int(hexst[i:i + 2], 16) for i in range(0, len(hexst), 2)])
    rn = len(fh) // width
    fh = numpy.reshape(fh[:rn * width], (-1, width))
    fh = numpy.uint8(fh)
    return fh


def mkdir(path):
    path = path.strip()
    path = path.rstrip("\\")
    isExists = os.path.exists(path)
    if not isExists:
        os.makedirs(path)
        print(path + " Created successfully")
        return True
    else:
        print(path + " Already exists")
        return False


def session2png(src_dst_paths):
    # im1 = Image.new('RGB', (64, 128), (255, 255, 255))
    # rgb1 = im1.split()[0]
    # im2 = Image.new('RGB', (64, 128), (255, 255, 255))
    # rgb2 = im2.split()[0]
    for src_dst_path in src_dst_paths:
        # dst_path = src_dst_path[1]
        # mkdir(dst_path)
        for src_idx, src_filename in enumerate(os.listdir(src_dst_path[0])):
            dst_path = os.path.join(src_dst_path[1], str(src_idx))
            mkdir(dst_path)
            for dst_filename in os.listdir(os.path.join(src_dst_path[0], src_filename)):
                bin_full_path = os.path.join(src_dst_path[0], src_filename, dst_filename)
                im0 = Image.fromarray(getMatrix_from_pcap(bin_full_path, PNG_WIDTH))
                rgb0 = im0.split()[0]
                im0.save("im0.jpg")

                TLSPD = TLSPcapDecode()
                print(bin_full_path)
                session_pcap = rdpcap(bin_full_path)
                session_statistic_features = get_session_statistic_feature(session_pcap, TLSPD)
                # print(session_statistic_features)
                tls_ca_data = session_statistic_features['tls_ca_data']
                if tls_ca_data:
                    im1 = Image.fromarray(getMatrix_from_str(tls_ca_data, PNG_WIDTH))
                else:
                    im1 = Image.new('RGB', (64, 128), (0, 0, 0))
                im1.save("im1.jpg")
                rgb1 = im1.split()[0]

                session_statistic_features.pop('si_sport_di_dport')
                session_statistic_features.pop('tls_ca_data')
                statistical_characteristic_data = ", ".join(str(v) for _, v in session_statistic_features.items())
                im2 = Image.fromarray(getMatrix_from_str(statistical_characteristic_data, PNG_WIDTH))
                im2.save("im2.jpg")
                rgb2 = im2.split()[0]

                im = Image.merge('RGB', (rgb0, rgb1, rgb2))
                # png_full_path = os.path.join(dst_path,  "000" + str(src_idx) + "_c" +  str(src_idx) + "_" + os.path.splitext(dst_filename)[0].replace(".", "_").replace("-", "_") + ".jpg")
                png_full_path = os.path.join(dst_path, os.path.splitext(dst_filename)[0] + ".jpg")
                im.save(png_full_path)


if __name__ == "__main__":
    src_dst_paths = [["3_Processedsession/FilteredSession/train", "4_png/train"],
                     ["3_ProcessedSession/FilteredSession/test", "4_Png/test"], ]
    session2png(src_dst_paths)
