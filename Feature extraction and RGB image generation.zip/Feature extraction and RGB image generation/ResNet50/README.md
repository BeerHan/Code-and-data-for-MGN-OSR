二分类问题的precision、recall、f1score

```python
        # TP predict 和 label 同时为1
        TP += ((predictions == 1) & (actuals == 1)).cpu().sum()
        # TN predict 和 label 同时为0
        TN += ((predictions == 0) & (actuals == 0)).cpu().sum()
        # FN predict 0 label 1
        FN += ((predictions == 0) & (actuals == 1)).cpu().sum()
        # FP predict 1 label 0
        FP += ((predictions == 1) & (actuals == 0)).cpu().sum()
        print("TP: {}, TN: {}, FN: {}, FP: {} ".format(TP, TN, FN, FP))
        try:
            precision.append((TP / (TP + FP)).numpy().tolist()[0])
            print("precision: ", precision[-1])
            recall.append((TP / (TP + FN)).numpy().tolist()[0])
            print("recall: ", recall[-1])
            f1score.append((2 * TP / (2 * TP + FN + FP)).numpy().tolist()[0])
            print("f1score: ", f1score[-1])
            # acc_tmp.append(((TP + TN) / (TP + TN + FP + FN)).numpy().tolist()[0])
        except:
            precision.append(0)
            recall.append(0)
            f1score.append(0)
avg_precision = sum(precision) / len(precision)
avg_recall = sum(recall) / len(recall)
avg_f1score = sum(f1score) / len(f1score)
# avg_acc_tmp = sum(acc_tmp) / len(acc_tmp)
# print("acc_tmp: {:.4f}".format(avg_acc_tmp))
# print("Precision: {:.4f}, Recall: {:.4f}, F1: {:.4f} ".format(avg_precision, avg_recall, avg_f1score))
print("Precision: {:.8f}, Recall: {:.8f}, F1 score: {:.8f} ".format(avg_precision, avg_recall, avg_f1score))
```