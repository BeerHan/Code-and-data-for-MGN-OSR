import torch
import torchvision
from torch import nn, optim
from torchvision import models
from sklearn.metrics import f1_score, confusion_matrix

import os
import time
import numpy as np
import matplotlib.pyplot as plt

from data import Data

print("PyTorch Version: ", torch.__version__)
print("Torchvision Version: ", torchvision.__version__)
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
# change this depend on your dataset
classes_num = 10
epochs_num = 25
labels_name = [i for i in range(10)]
axis_labels = ["Bunitu", "CCleaner", "Dridex", "Emotet", "Heuristic", "HPEMOTET", "PUA.Taobao", "Razy", "Trickbot",
               "WannaCry"]


class Main():
    def __init__(self, model, data):
        self.dataset = data.dataset
        self.train_data_size = data.train_data_size
        self.test_data_size = data.test_data_size
        self.train_loader = data.train_loader
        self.test_loader = data.test_loader

        self.model = model.to("cuda")
        self.loss = nn.NLLLoss()
        self.optimizer = optim.Adam(model.parameters())

    def train_and_test(self):
        history = []
        best_acc = 0.0
        best_epoch = 0

        for epoch in range(epochs_num):
            epoch_start = time.time()
            print("Epoch: {}/{}".format(epoch + 1, epochs_num))
            self.model.train()
            train_loss = 0.0
            train_acc = 0.0
            test_loss = 0.0
            test_acc = 0.0
            macro_f1, micro_f1 = [], []
            actuals_t, predictions_t = [], []
            for i, (inputs, labels) in enumerate(self.train_loader):
                inputs = inputs.to(device)
                labels = labels.to(device)
                # 因为这里梯度是累加的，所以每次记得清零
                self.optimizer.zero_grad()
                outputs = self.model(inputs)
                loss = self.loss(outputs, labels)
                loss.backward()
                self.optimizer.step()
                train_loss += loss.item() * inputs.size(0)
                ret, predictions = torch.max(outputs.data, 1)
                actuals = labels.data.view_as(predictions)
                correct_counts = predictions.eq(actuals)
                acc = torch.mean(correct_counts.type(torch.FloatTensor))
                train_acc += acc.item() * inputs.size(0)

            with torch.no_grad():
                model.eval()
                for j, (inputs, labels) in enumerate(self.test_loader):
                    inputs = inputs.to(device)
                    labels = labels.to(device)
                    outputs = self.model(inputs)
                    loss = self.loss(outputs, labels)
                    test_loss += loss.item() * inputs.size(0)
                    ret, predictions = torch.max(outputs.data, 1)
                    actuals = labels.data.view_as(predictions)
                    correct_counts = predictions.eq(actuals)
                    # print("num: ", correct_counts, "\nnum type: ", type(correct_counts))
                    acc = torch.mean(correct_counts.type(torch.FloatTensor))
                    test_acc += acc.item() * inputs.size(0)
                    # print("train_acc: ", train_acc)

                    actuals = actuals.cpu()
                    predictions = predictions.cpu()
                    # print("true lable: ", actuals)
                    # print("prediction lable: ", predictions)
                    macro_f1.append(f1_score(actuals, predictions, average="macro"))
                    micro_f1.append(f1_score(actuals, predictions, average="micro"))
                    # print(f"macro_f1: {macro_f1[-1]}, micro_f1: {micro_f1[-1]}")
                    actuals_t.extend(actuals.numpy().tolist())
                    predictions_t.extend(predictions.numpy().tolist())

            # 多分类问题的F1值：macro 和 micro
            macro_f1_avg = sum(macro_f1) / len(macro_f1)
            micro_f1_avg = sum(micro_f1) / len(micro_f1)
            # print(f"macro_f1: {macro_f1_avg:.4f}, micro_f1: {micro_f1_avg:.4f}")
            # 混淆矩阵
            plot_confusion_matrix(epoch, actuals_t, predictions_t, [i for i in range(10)], title='10Class_cm',
                                  axis_labels=axis_labels)
            # loss和accuracy
            train_loss_avg = train_loss / self.train_data_size
            train_acc_avg = train_acc / self.train_data_size
            test_loss_avg = test_loss / self.test_data_size
            test_acc_avg = test_acc / self.test_data_size
            history.append([train_loss_avg, test_loss_avg, train_acc_avg, test_acc_avg])
            if best_acc < test_acc_avg:
                best_acc = test_acc_avg
                best_epoch = epoch + 1
            epoch_end = time.time()

            print(
                "Epoch: {:03d}\n\tTraining: Loss: {:.4f}, Accuracy: {:.4f}%, \n\tValidation: Loss: {:.4f}, Accuracy: {:.4f}%, Macro_F1: {:.4f}, Micro_F1: {:.4f},\n\tTime: {:.4f}s".format(
                    epoch + 1, train_loss_avg, train_acc_avg * 100, test_loss_avg, test_acc_avg * 100, macro_f1_avg,
                    micro_f1_avg, epoch_end - epoch_start))
            print("Best Accuracy for validation : {:.4f} at epoch {:03d}".format(best_acc, best_epoch))
            torch.save(model, "weights/" + self.dataset + "_model_" + str(epoch + 1) + ".pt")
        return model, history


def plot_confusion_matrix(epoch, y_true, y_pred, labels_name, title=None, thresh=0.9, axis_labels=None):
    plt.figure(figsize=(8, 8))
    # 利用sklearn中的函数生成混淆矩阵并归一化
    cm = confusion_matrix(y_true, y_pred, labels=labels_name, sample_weight=None)  # 生成混淆矩阵
    cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]  # 归一化
    # 画图，如果希望改变颜色风格，可以改变此部分的cmap=pl.get_cmap('Blues')处
    plt.imshow(cm, interpolation='nearest', cmap=plt.get_cmap('Blues'))
    plt.colorbar()  # 绘制图例
    # 图像标题
    if title is not None:
        plt.title(title)
    # 绘制坐标
    num_local = np.array(range(len(labels_name)))
    if axis_labels is None:
        axis_labels = labels_name
    plt.xticks(num_local, axis_labels, rotation=45)  # 将标签印在x轴坐标上， 并倾斜45度
    plt.yticks(num_local, axis_labels)  # 将标签印在y轴坐标上
    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    # 将百分比打印在相应的格子内，大于thresh的用白字，小于的用黑字
    for i in range(np.shape(cm)[0]):
        for j in range(np.shape(cm)[1]):
            if int(cm[i][j] * 100 + 0.5) > 0:
                plt.text(j, i, format(int(cm[i][j] * 100 + 0.5), 'd') + '%', ha="center", va="center",
                         color="white" if cm[i][j] > thresh else "black")  # 如果要更改颜色风格，需要同时更改此行
    # 显示
    plt.savefig(f"images/epoch_{epoch + 1}_cm.jpg", bbox_inches="tight")
    plt.show()


def plot_accuracy_loss_curve(history):
    history = np.array(history)
    plt.plot(history[:, 0:2])
    plt.legend(["Tr Loss", "Val Loss"])
    plt.xlabel("Epoch Number")
    plt.ylabel("Loss")
    plt.ylim(0, 1)
    plt.savefig("images/loss_curve.png")
    plt.show()

    plt.plot(history[:, 2:4])
    plt.legend(["Tr Accuracy", "Val Accuracy"])
    plt.xlabel("Epoch Number")
    plt.ylabel("Accuracy")
    plt.ylim(0, 1)
    plt.savefig("images/accuracy_curve.png")
    plt.show()


if __name__ == '__main__':
    os.makedirs("weights", exist_ok=True)
    os.makedirs("images", exist_ok=True)
    # data
    data = Data()
    # network
    model = models.resnet50(pretrained=True)
    for param in model.parameters():
        param.requires_grad = False
    fc_inputs = model.fc.in_features
    model.fc = nn.Sequential(
        nn.Linear(fc_inputs, 256),
        nn.ReLU(),
        nn.Dropout(0.4),
        nn.Linear(256, classes_num),
        nn.LogSoftmax(dim=1)
    )
    # main
    main = Main(model, data)
    trained_model, history = main.train_and_test()
    torch.save(history, "weights/" + main.dataset + "_history.pt")
    plot_accuracy_loss_curve(history)
