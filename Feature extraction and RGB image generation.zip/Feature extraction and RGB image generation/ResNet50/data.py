import os

from torchvision import transforms, datasets
from torch.utils.data import dataloader

batch_size = 32


class Data():
    def __init__(self):
        # 数据增强，可修剪
        image_transforms = {
            'train': transforms.Compose([
                transforms.RandomResizedCrop(size=256, scale=(0.8, 1.0)),
                transforms.RandomRotation(degrees=15),
                transforms.RandomHorizontalFlip(),
                transforms.CenterCrop(size=224),
                transforms.ToTensor(),
                transforms.Normalize([0.485, 0.456, 0.406],
                                     [0.229, 0.224, 0.225])
            ]),
            'test': transforms.Compose([
                transforms.Resize(size=256),
                transforms.CenterCrop(size=224),
                transforms.ToTensor(),
                transforms.Normalize([0.485, 0.456, 0.406],
                                     [0.229, 0.224, 0.225])
            ])
        }
        # data path
        self.dataset = 'MaliciousTraffic-2001-v20.11.25'
        self.train_directory = os.path.join(self.dataset, 'train')
        self.test_directory = os.path.join(self.dataset, 'test')

        data = {
            'train': datasets.ImageFolder(root=self.train_directory, transform=image_transforms['train']),
            'test': datasets.ImageFolder(root=self.test_directory, transform=image_transforms['test'])
        }
        self.train_data_size = len(data['train'])
        self.test_data_size = len(data['test'])
        print("train data size: ", self.train_data_size, "\ntest data size: ", self.test_data_size)

        self.train_loader = dataloader.DataLoader(data['train'], batch_size=batch_size, shuffle=True)
        self.test_loader = dataloader.DataLoader(data['test'], batch_size=batch_size, shuffle=True)
